package com.SuSyKnower;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuSyKnowerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuSyKnowerApplication.class, args);
	}

}
